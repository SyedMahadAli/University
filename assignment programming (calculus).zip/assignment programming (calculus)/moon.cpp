#include<iostream>
using namespace std;
main()
{  char ch;
	cout<<"enter the character:";
	cin>>ch;
	int a=20;
	for(int i=1;i<=5;i++)
	{
		a=a-2;
		for(int j=1;j<=a;j++)
		{
			cout<<" ";
		}
		for(int k=1;k<=i;k++)
		{
			cout<<ch;
			
		}
		cout<<endl;
	}

	
		int b=10;
	for(int i=1;i<=3;i++)
	{
	
		b=b-1;
		for(int j=1;j<=b;j++)
		{
			cout<<" ";
		}
		for(int k=1;k<=5;k++)
		{
			cout<<ch;
		}
		cout<<endl;
	}
	

			int c=7;
	for(int i=1;i<=2;i++)
	{
	
		
		for(int j=1;j<=c;j++)
		{
			cout<<" ";
		}
		for(int k=1;k<=5;k++)
		{
			cout<<ch;
		}
		cout<<endl;
	}

			int d=7;
	for(int i=1;i<=3;i++)
	{
	
		d=d+1;
		for(int j=1;j<=d;j++)
		{
			cout<<" ";
		}
		for(int k=1;k<=5;k++)
		{
			cout<<ch;
		}
		cout<<endl;
		
		}

       	int x=10,w=5;
	for(int i=1;i<=5;i++)
	{
		x=x+2;
		w=w-1;
		for(int e=1;e<=x;e++)
		{
			cout<<" ";
		}
		for(int f=1;f<=w;f++)
		{
			cout<<ch;
			
		}
		cout<<endl;
	}
}

