#include<iostream>
using namespace std;
main()
{
	int b;
	char a;
		cout<<"enter the character:";
		cin>>a;
		cout<<"ending no:";
		cin>>b;
		
		for(int i=1;i<=b;i++)
		{
			for(int j=1;j<=i;j++)
			{
				cout<<a;
			}
			cout<<endl;
		}
}
		
		
		
		
		
		
		/*
	
		int c;
		c=b;
	for(int i=1;i<=b;i++)
	{
		c--;
		for(int k=1;k<=c;k++)
		{
			cout<<" ";
		}
	     for(int j=1;j<=i;j++)
	     {
	     	cout<<a;
		 }
		 cout<<endl;
	}
}
   */