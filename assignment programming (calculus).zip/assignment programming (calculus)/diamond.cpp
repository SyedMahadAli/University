#include<iostream>
using namespace std;
main()
{
	int b,c,d,e;
	char a;
	cout<<"enter the character:";
	cin>>a;
	cout<<"enter the ending range:";
	cin>>b;
	d=b;
	
	for(int i=1;i<=b;i++)
	{   d--;
		for(int j=1;j<=d;j++)
		{
			cout<<" ";
		}
		for(int k=1;k<=i;k++)
		{
			cout<<a;
			cout<<" ";
		}
		cout<<endl;
		
  		}

	    e=b;
	     int h=0;
	for(int i=e;i>=1;i--)
{

	     h++;
		for(int j=1;j<=h;j++)
		{cout<<" ";
		}
		for(int k=i;k>=2;k--)
		{
			cout<<a;
			cout<<" ";
		}
		cout<<endl;
}
	
}

     