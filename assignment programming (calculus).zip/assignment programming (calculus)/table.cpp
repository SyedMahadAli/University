#include<iostream>
using namespace std;
main()
{
	int a,b;
	cout<<"enter the no for table";
	cin>>a;
	cout<<"enter the ending digit";
	cin>>b;
	for(int c=1;c<=b;c++)
	{
		cout<<a<<"*"<<c<<"="<<a*c<<endl;
	}
}
