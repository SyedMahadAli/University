#include<iostream>
using namespace std;
int main()
{
	int l,w;
	cout<<"Enter length of rectangle:";
	cin>>l;
	cout<<"Enter width of rectangle:";
	cin>>w;
	
	for(int i=1;i<=l;i++)     //for length
	{
		cout<<"@";
	}
	for(int j=1;j<=w;j++)     ///for width
	{
		int d=l;
		d=d-2;
		cout<<endl;
		cout<<"@";
		for(int k=1;k<=d;k++)
		{
			cout<<" ";	
		}
		cout<<"@";
	}
	cout<<endl;
	for(int i=1;i<=l;i++)
	{
		cout<<"@";
	}

	
	
	cout<<endl;
}